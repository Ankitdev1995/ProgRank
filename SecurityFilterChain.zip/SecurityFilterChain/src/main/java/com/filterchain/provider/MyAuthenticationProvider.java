package com.filterchain.provider;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import com.filterchain.filter.MyCustomAuthenticationToken;


public class MyAuthenticationProvider implements AuthenticationProvider {

	@Value("${secret_key}")
	String secret_key;

	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		if(secret_key.equals(authentication.getName())) {
			return new MyCustomAuthenticationToken(null, null, null);
		}
		return null;
		
	}

	
	@Override
	public boolean supports(Class<?> authentication) {

		return  MyCustomAuthenticationToken.class.equals(authentication);
	}

}
