package com.filterchain.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class MyBasicAuthenticationFilter implements Filter{

	@Autowired
	AuthenticationManager authenticationManager;

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		// based upon request
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		String authObj = httpServletRequest.getHeader("secret_key");

		// create authentication object
		var objToken = 	new	MyCustomAuthenticationToken(authObj, null);

		
		try {
			// delegate object to authenticationManager --> AuthenticationProvider
		var authPrincipal = authenticationManager.authenticate(objToken);
		
		// for future use save principal into SecurityContext
		if(authPrincipal.isAuthenticated()) {
			SecurityContextHolder.getContext().setAuthentication(authPrincipal);
			chain.doFilter(request, response);
		}
		}catch(AuthenticationException e) {
			new BadCredentialsException("Invalid principal");	
		}
		}
	}	


