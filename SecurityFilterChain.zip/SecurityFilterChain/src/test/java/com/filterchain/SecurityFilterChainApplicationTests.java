package com.filterchain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityFilterChainApplicationTests {

	@Test
	void contextLoads() {
	}

}
