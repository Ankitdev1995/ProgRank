package com.becoderr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityLoginAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
