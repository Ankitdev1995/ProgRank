package com.becoderr.service;

import com.becoderr.entity.User;

public interface UserService {

	
	public User saveUser(User user);
	
	public void removeSessionMessage();
	
}
