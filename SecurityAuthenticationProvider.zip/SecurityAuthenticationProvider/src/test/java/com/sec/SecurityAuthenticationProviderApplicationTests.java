package com.sec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityAuthenticationProviderApplicationTests {

	@Test
	void contextLoads() {
	}

}
