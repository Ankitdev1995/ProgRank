package com.becoderr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityLoginAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityLoginAppApplication.class, args);
		System.out.println("success");
	}

}
