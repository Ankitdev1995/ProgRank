package com.pragy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prog3Application {

	public static void main(String[] args) {
		SpringApplication.run(Prog3Application.class, args);
	System.out.println("Success");
	}

}
