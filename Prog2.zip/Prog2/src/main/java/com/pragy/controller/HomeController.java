package com.pragy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pragy.entity.User;
import com.pragy.service.MyUserService;


@RestController
public class HomeController {
		
	@Autowired
	MyUserService myUserService;
	
	@GetMapping("/index")
	public String check() {
		return "spring security using userDetailsManager..";
	}
	
	
	@PostMapping("/createUser")
	public String addUser(@RequestBody User user) {
		myUserService.addUser(user);
		return "users data saved";
	}
	
}
