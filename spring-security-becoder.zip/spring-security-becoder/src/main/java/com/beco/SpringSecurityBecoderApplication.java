package com.beco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityBecoderApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityBecoderApplication.class, args);
	System.out.println("success");
	
	}
	
}
