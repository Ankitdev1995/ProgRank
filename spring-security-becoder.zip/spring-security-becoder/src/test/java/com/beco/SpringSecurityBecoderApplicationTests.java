package com.beco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityBecoderApplicationTests {

	@Test
	void contextLoads() {
	}

}
