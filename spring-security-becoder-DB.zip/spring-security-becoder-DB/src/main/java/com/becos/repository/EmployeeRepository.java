package com.becos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.becos.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	
	public Employee findByEmail(String email);
}
