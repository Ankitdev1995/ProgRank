package com.becos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityBecoderDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityBecoderDbApplication.class, args);
		System.out.println("Success");
	}
}
