package com.becoderr.config;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import com.becoderr.entity.User;
import com.becoderr.repository.UserRepository;
import com.becoderr.service.UserService;
import com.becoderr.service.UserServiceImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class CustomFailureHandler extends SimpleUrlAuthenticationFailureHandler{

	@Autowired
	private UserService userService;

	@Autowired
	private UserRepository userRepository;

	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {

		String email = request.getParameter("username");
		User user = userRepository.findByEmail(email);

		if(user!=null) {

			if(user.isEnable()) {

				if(user.isAccountNonLocked()) {

				//	             0  < 3-1 = 2 true  // then attempt will be 1 means failed attempt is 1
				// 	             1  < 2-1 = 1 true
 					if(user.getFailedAttempt()<UserServiceImpl.ATTEMPT_TIME-1) {
						userService.increaseFailedAttempt(user);
					}else {
						userService.lock(user);
						exception  = new LockedException("Your account is locked...failed attempts 3");
					}
				}else if(!user.isAccountNonLocked()) {
					if(userService.unlockAccountTimeExpired(user)) {
						exception = new LockedException("Account is unlock .. please try to login");
					}else {
						exception = new LockedException("Account is lock .. please try After some time");
					}
				}
			}else {
				exception = new LockedException("Account is inactive.. verify account");
			}
		}
		super.setDefaultFailureUrl("/signIn?error");
		super.onAuthenticationFailure(request, response, exception);
	}
}
