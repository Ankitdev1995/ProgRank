package com.becoderr.service;

import com.becoderr.entity.User;

public interface UserService {

	public User saveUser(User user, String url);
	
	public void removeSessionMessage();
	
	public void sendEmail(User user, String path);
	
	public boolean verifyAccount(String verificationCode);
	
	public void increaseFailedAttempt(User user);
	
	public void resetAttempt(String email); // if user login successfully then by default attempt will be zero.
	
	public void lock(User user); // if password wrong 3 times then account will be lock
	
	public boolean unlockAccountTimeExpired(User user); // users account will be unlock after expiring the time
	
}
