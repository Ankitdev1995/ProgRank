package com.lcwd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookRestBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookRestBookApplication.class, args);
		System.out.println("success");
	}
}
